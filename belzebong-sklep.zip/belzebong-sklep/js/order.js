const orderButton = document.querySelector('.order-button');

orderButton.addEventListener('click', (e) => {
    e.preventDefault();
    const items = document.querySelectorAll('.item-name');
    // items.map(el => el.innerHTML)
    console.log('click order: ', items);


})